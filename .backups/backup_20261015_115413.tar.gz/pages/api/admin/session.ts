import type { NextApiRequest, NextApiResponse } from 'next';
import { verify } from 'jsonwebtoken';

const SECRET = process.env.JWT_SECRET;

interface SessionPayload {
  userId: number;
  role: string;
  iat: number;
  exp: number;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    res.setHeader('Allow', ['GET']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  try {
    const token = req.cookies['auth_token'];
    if (!token || !SECRET) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    const payload = verify(token, SECRET) as SessionPayload;

    if (!payload || !payload.userId) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    res.status(200).json({ userId: payload.userId, role: payload.role });
  } catch (err) {
    console.error(err);
    res.status(401).json({ message: 'Invalid or expired session' });
  }
}
